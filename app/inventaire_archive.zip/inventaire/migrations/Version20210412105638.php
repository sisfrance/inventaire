<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210412105638 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE client (id INT AUTO_INCREMENT NOT NULL, client VARCHAR(50) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE emplacement (site_id INT DEFAULT NULL, Id INT AUTO_INCREMENT NOT NULL, etage VARCHAR(10) DEFAULT NULL, numero VARCHAR(30) DEFAULT NULL, batiment VARCHAR(10) DEFAULT NULL, emplacement VARCHAR(30) DEFAULT NULL, INDEX IDX_C0CF65F6F6BD1646 (site_id), PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE fonction (Id INT AUTO_INCREMENT NOT NULL, fonction VARCHAR(255) NOT NULL, PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE fournisseur (Id INT AUTO_INCREMENT NOT NULL, fournisseur VARCHAR(30) NOT NULL, telephone VARCHAR(15) DEFAULT NULL, mail VARCHAR(150) DEFAULT NULL, PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE lecteur_reseau (id INT AUTO_INCREMENT NOT NULL, ordinateur_id INT DEFAULT NULL, adresse_ip VARCHAR(16) DEFAULT NULL, nom_hote VARCHAR(50) DEFAULT NULL, nom_partage VARCHAR(150) DEFAULT NULL, chemin_complet VARCHAR(150) DEFAULT NULL, INDEX IDX_BF4D5A01828317CA (ordinateur_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE lecteur_reseau_session (lecteur_reseau_id INT NOT NULL, session_id INT NOT NULL, INDEX IDX_CE5204B92FBA274B (lecteur_reseau_id), INDEX IDX_CE5204B9613FECDF (session_id), PRIMARY KEY(lecteur_reseau_id, session_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE marque (Id INT AUTO_INCREMENT NOT NULL, marque VARCHAR(20) NOT NULL, tel_support VARCHAR(12) DEFAULT NULL, PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE modele (marque_id INT DEFAULT NULL, Id INT AUTO_INCREMENT NOT NULL, modele VARCHAR(50) NOT NULL, INDEX IDX_100285584827B9B2 (marque_id), PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE office (id INT AUTO_INCREMENT NOT NULL, ordinateur_id INT DEFAULT NULL, version_office_id INT DEFAULT NULL, courrier VARCHAR(15) DEFAULT NULL, INDEX IDX_74516B02828317CA (ordinateur_id), INDEX IDX_74516B02F117B04A (version_office_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE ordinateur (modele_id INT DEFAULT NULL, typeordinateur_id INT DEFAULT NULL, processeur_id INT DEFAULT NULL, fournisseur_id INT DEFAULT NULL, os_id INT DEFAULT NULL, emplacement_id INT DEFAULT NULL, Id INT AUTO_INCREMENT NOT NULL, reference VARCHAR(20) DEFAULT NULL, ram VARCHAR(10) DEFAULT NULL, date_achat DATE DEFAULT NULL, ipadresse VARCHAR(15) DEFAULT NULL, notes LONGTEXT DEFAULT NULL, serialnumber VARCHAR(30) DEFAULT NULL, nom_pc VARCHAR(50) DEFAULT NULL, INDEX IDX_8712E8DBAC14B70A (modele_id), INDEX IDX_8712E8DB5F9BCF66 (typeordinateur_id), INDEX IDX_8712E8DB5C9BE5AD (processeur_id), INDEX IDX_8712E8DB670C757F (fournisseur_id), INDEX IDX_8712E8DB3DCA04D1 (os_id), INDEX IDX_8712E8DBC4598A51 (emplacement_id), PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE ordinateur_peripherique (ordinateur_id INT NOT NULL, peripherique_id INT NOT NULL, INDEX IDX_6767D66D828317CA (ordinateur_id), INDEX IDX_6767D66D8AB40D6 (peripherique_id), PRIMARY KEY(ordinateur_id, peripherique_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE os (Id INT AUTO_INCREMENT NOT NULL, os VARCHAR(50) NOT NULL, version VARCHAR(15) DEFAULT NULL, notes LONGTEXT DEFAULT NULL, PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE peripherique (typeperipherique_id INT DEFAULT NULL, modele_id INT DEFAULT NULL, emplacement_id INT DEFAULT NULL, Id INT AUTO_INCREMENT NOT NULL, reference VARCHAR(15) DEFAULT NULL, serialnumber VARCHAR(30) DEFAULT NULL, notes LONGTEXT DEFAULT NULL, ipadresse VARCHAR(15) DEFAULT NULL, INDEX IDX_CFCF0365821134CD (typeperipherique_id), INDEX IDX_CFCF0365AC14B70A (modele_id), INDEX IDX_CFCF0365C4598A51 (emplacement_id), PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE poste_de_travail (id INT AUTO_INCREMENT NOT NULL, emplacement_id INT DEFAULT NULL, ordinateur_id INT DEFAULT NULL, INDEX IDX_DD84E80AC4598A51 (emplacement_id), INDEX IDX_DD84E80A828317CA (ordinateur_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE processeur (Id INT AUTO_INCREMENT NOT NULL, processeur VARCHAR(25) NOT NULL, PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE service (id INT AUTO_INCREMENT NOT NULL, emplacement_id INT DEFAULT NULL, service VARCHAR(50) NOT NULL, INDEX IDX_E19D9AD2C4598A51 (emplacement_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE session (id INT AUTO_INCREMENT NOT NULL, type VARCHAR(30) DEFAULT NULL, session VARCHAR(50) NOT NULL, mdp VARCHAR(50) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE session_utilisateur (session_id INT NOT NULL, utilisateur_id INT NOT NULL, INDEX IDX_E1457DC4613FECDF (session_id), INDEX IDX_E1457DC4FB88E14F (utilisateur_id), PRIMARY KEY(session_id, utilisateur_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE site (id INT AUTO_INCREMENT NOT NULL, client_id INT NOT NULL, site VARCHAR(50) NOT NULL, adresse VARCHAR(150) DEFAULT NULL, cp VARCHAR(7) DEFAULT NULL, ville VARCHAR(50) DEFAULT NULL, abr VARCHAR(10) DEFAULT NULL, INDEX IDX_694309E419EB6921 (client_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE telephone (modele_id INT DEFAULT NULL, emplacement_id INT DEFAULT NULL, Id INT AUTO_INCREMENT NOT NULL, reference VARCHAR(20) DEFAULT NULL, numero VARCHAR(15) DEFAULT NULL, INDEX IDX_450FF010AC14B70A (modele_id), INDEX IDX_450FF010C4598A51 (emplacement_id), PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE type_ordinateur (Id INT AUTO_INCREMENT NOT NULL, type VARCHAR(15) NOT NULL, PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE type_peripherique (Id INT AUTO_INCREMENT NOT NULL, type VARCHAR(15) NOT NULL, abr VARCHAR(5) DEFAULT NULL, PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE utilisateur (fonction_id INT DEFAULT NULL, postedetravail_id INT DEFAULT NULL, service_id INT DEFAULT NULL, Id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, INDEX IDX_1D1C63B357889920 (fonction_id), INDEX IDX_1D1C63B3EA6D4B67 (postedetravail_id), INDEX IDX_1D1C63B3ED5CA9E6 (service_id), PRIMARY KEY(Id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE version_office (id INT AUTO_INCREMENT NOT NULL, version VARCHAR(30) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE vpn (id INT AUTO_INCREMENT NOT NULL, utilisateur_id INT DEFAULT NULL, compte VARCHAR(25) NOT NULL, mdp VARCHAR(150) NOT NULL, INDEX IDX_2A08F859FB88E14F (utilisateur_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE emplacement ADD CONSTRAINT FK_C0CF65F6F6BD1646 FOREIGN KEY (site_id) REFERENCES site (id)');
        $this->addSql('ALTER TABLE lecteur_reseau ADD CONSTRAINT FK_BF4D5A01828317CA FOREIGN KEY (ordinateur_id) REFERENCES ordinateur (id)');
        $this->addSql('ALTER TABLE lecteur_reseau_session ADD CONSTRAINT FK_CE5204B92FBA274B FOREIGN KEY (lecteur_reseau_id) REFERENCES lecteur_reseau (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE lecteur_reseau_session ADD CONSTRAINT FK_CE5204B9613FECDF FOREIGN KEY (session_id) REFERENCES session (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE modele ADD CONSTRAINT FK_100285584827B9B2 FOREIGN KEY (marque_id) REFERENCES marque (Id)');
        $this->addSql('ALTER TABLE office ADD CONSTRAINT FK_74516B02828317CA FOREIGN KEY (ordinateur_id) REFERENCES ordinateur (Id)');
        $this->addSql('ALTER TABLE office ADD CONSTRAINT FK_74516B02F117B04A FOREIGN KEY (version_office_id) REFERENCES version_office (id)');
        $this->addSql('ALTER TABLE ordinateur ADD CONSTRAINT FK_8712E8DBAC14B70A FOREIGN KEY (modele_id) REFERENCES modele (Id)');
        $this->addSql('ALTER TABLE ordinateur ADD CONSTRAINT FK_8712E8DB5F9BCF66 FOREIGN KEY (typeordinateur_id) REFERENCES type_ordinateur (Id)');
        $this->addSql('ALTER TABLE ordinateur ADD CONSTRAINT FK_8712E8DB5C9BE5AD FOREIGN KEY (processeur_id) REFERENCES processeur (Id)');
        $this->addSql('ALTER TABLE ordinateur ADD CONSTRAINT FK_8712E8DB670C757F FOREIGN KEY (fournisseur_id) REFERENCES fournisseur (Id)');
        $this->addSql('ALTER TABLE ordinateur ADD CONSTRAINT FK_8712E8DB3DCA04D1 FOREIGN KEY (os_id) REFERENCES os (Id)');
        $this->addSql('ALTER TABLE ordinateur ADD CONSTRAINT FK_8712E8DBC4598A51 FOREIGN KEY (emplacement_id) REFERENCES emplacement (Id)');
        $this->addSql('ALTER TABLE ordinateur_peripherique ADD CONSTRAINT FK_6767D66D828317CA FOREIGN KEY (ordinateur_id) REFERENCES ordinateur (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE ordinateur_peripherique ADD CONSTRAINT FK_6767D66D8AB40D6 FOREIGN KEY (peripherique_id) REFERENCES peripherique (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE peripherique ADD CONSTRAINT FK_CFCF0365821134CD FOREIGN KEY (typeperipherique_id) REFERENCES type_peripherique (Id)');
        $this->addSql('ALTER TABLE peripherique ADD CONSTRAINT FK_CFCF0365AC14B70A FOREIGN KEY (modele_id) REFERENCES modele (Id)');
        $this->addSql('ALTER TABLE peripherique ADD CONSTRAINT FK_CFCF0365C4598A51 FOREIGN KEY (emplacement_id) REFERENCES emplacement (Id)');
        $this->addSql('ALTER TABLE poste_de_travail ADD CONSTRAINT FK_DD84E80AC4598A51 FOREIGN KEY (emplacement_id) REFERENCES emplacement (Id)');
        $this->addSql('ALTER TABLE poste_de_travail ADD CONSTRAINT FK_DD84E80A828317CA FOREIGN KEY (ordinateur_id) REFERENCES ordinateur (Id)');
        $this->addSql('ALTER TABLE service ADD CONSTRAINT FK_E19D9AD2C4598A51 FOREIGN KEY (emplacement_id) REFERENCES emplacement (Id)');
        $this->addSql('ALTER TABLE session_utilisateur ADD CONSTRAINT FK_E1457DC4613FECDF FOREIGN KEY (session_id) REFERENCES session (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE session_utilisateur ADD CONSTRAINT FK_E1457DC4FB88E14F FOREIGN KEY (utilisateur_id) REFERENCES utilisateur (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE site ADD CONSTRAINT FK_694309E419EB6921 FOREIGN KEY (client_id) REFERENCES client (id)');
        $this->addSql('ALTER TABLE telephone ADD CONSTRAINT FK_450FF010AC14B70A FOREIGN KEY (modele_id) REFERENCES modele (Id)');
        $this->addSql('ALTER TABLE telephone ADD CONSTRAINT FK_450FF010C4598A51 FOREIGN KEY (emplacement_id) REFERENCES emplacement (Id)');
        $this->addSql('ALTER TABLE utilisateur ADD CONSTRAINT FK_1D1C63B357889920 FOREIGN KEY (fonction_id) REFERENCES fonction (Id)');
        $this->addSql('ALTER TABLE utilisateur ADD CONSTRAINT FK_1D1C63B3EA6D4B67 FOREIGN KEY (postedetravail_id) REFERENCES poste_de_travail (id)');
        $this->addSql('ALTER TABLE utilisateur ADD CONSTRAINT FK_1D1C63B3ED5CA9E6 FOREIGN KEY (service_id) REFERENCES service (id)');
        $this->addSql('ALTER TABLE vpn ADD CONSTRAINT FK_2A08F859FB88E14F FOREIGN KEY (utilisateur_id) REFERENCES utilisateur (Id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE site DROP FOREIGN KEY FK_694309E419EB6921');
        $this->addSql('ALTER TABLE ordinateur DROP FOREIGN KEY FK_8712E8DBC4598A51');
        $this->addSql('ALTER TABLE peripherique DROP FOREIGN KEY FK_CFCF0365C4598A51');
        $this->addSql('ALTER TABLE poste_de_travail DROP FOREIGN KEY FK_DD84E80AC4598A51');
        $this->addSql('ALTER TABLE service DROP FOREIGN KEY FK_E19D9AD2C4598A51');
        $this->addSql('ALTER TABLE telephone DROP FOREIGN KEY FK_450FF010C4598A51');
        $this->addSql('ALTER TABLE utilisateur DROP FOREIGN KEY FK_1D1C63B357889920');
        $this->addSql('ALTER TABLE ordinateur DROP FOREIGN KEY FK_8712E8DB670C757F');
        $this->addSql('ALTER TABLE lecteur_reseau_session DROP FOREIGN KEY FK_CE5204B92FBA274B');
        $this->addSql('ALTER TABLE modele DROP FOREIGN KEY FK_100285584827B9B2');
        $this->addSql('ALTER TABLE ordinateur DROP FOREIGN KEY FK_8712E8DBAC14B70A');
        $this->addSql('ALTER TABLE peripherique DROP FOREIGN KEY FK_CFCF0365AC14B70A');
        $this->addSql('ALTER TABLE telephone DROP FOREIGN KEY FK_450FF010AC14B70A');
        $this->addSql('ALTER TABLE lecteur_reseau DROP FOREIGN KEY FK_BF4D5A01828317CA');
        $this->addSql('ALTER TABLE office DROP FOREIGN KEY FK_74516B02828317CA');
        $this->addSql('ALTER TABLE ordinateur_peripherique DROP FOREIGN KEY FK_6767D66D828317CA');
        $this->addSql('ALTER TABLE poste_de_travail DROP FOREIGN KEY FK_DD84E80A828317CA');
        $this->addSql('ALTER TABLE ordinateur DROP FOREIGN KEY FK_8712E8DB3DCA04D1');
        $this->addSql('ALTER TABLE ordinateur_peripherique DROP FOREIGN KEY FK_6767D66D8AB40D6');
        $this->addSql('ALTER TABLE utilisateur DROP FOREIGN KEY FK_1D1C63B3EA6D4B67');
        $this->addSql('ALTER TABLE ordinateur DROP FOREIGN KEY FK_8712E8DB5C9BE5AD');
        $this->addSql('ALTER TABLE utilisateur DROP FOREIGN KEY FK_1D1C63B3ED5CA9E6');
        $this->addSql('ALTER TABLE lecteur_reseau_session DROP FOREIGN KEY FK_CE5204B9613FECDF');
        $this->addSql('ALTER TABLE session_utilisateur DROP FOREIGN KEY FK_E1457DC4613FECDF');
        $this->addSql('ALTER TABLE emplacement DROP FOREIGN KEY FK_C0CF65F6F6BD1646');
        $this->addSql('ALTER TABLE ordinateur DROP FOREIGN KEY FK_8712E8DB5F9BCF66');
        $this->addSql('ALTER TABLE peripherique DROP FOREIGN KEY FK_CFCF0365821134CD');
        $this->addSql('ALTER TABLE session_utilisateur DROP FOREIGN KEY FK_E1457DC4FB88E14F');
        $this->addSql('ALTER TABLE vpn DROP FOREIGN KEY FK_2A08F859FB88E14F');
        $this->addSql('ALTER TABLE office DROP FOREIGN KEY FK_74516B02F117B04A');
        $this->addSql('DROP TABLE client');
        $this->addSql('DROP TABLE emplacement');
        $this->addSql('DROP TABLE fonction');
        $this->addSql('DROP TABLE fournisseur');
        $this->addSql('DROP TABLE lecteur_reseau');
        $this->addSql('DROP TABLE lecteur_reseau_session');
        $this->addSql('DROP TABLE marque');
        $this->addSql('DROP TABLE modele');
        $this->addSql('DROP TABLE office');
        $this->addSql('DROP TABLE ordinateur');
        $this->addSql('DROP TABLE ordinateur_peripherique');
        $this->addSql('DROP TABLE os');
        $this->addSql('DROP TABLE peripherique');
        $this->addSql('DROP TABLE poste_de_travail');
        $this->addSql('DROP TABLE processeur');
        $this->addSql('DROP TABLE service');
        $this->addSql('DROP TABLE session');
        $this->addSql('DROP TABLE session_utilisateur');
        $this->addSql('DROP TABLE site');
        $this->addSql('DROP TABLE telephone');
        $this->addSql('DROP TABLE type_ordinateur');
        $this->addSql('DROP TABLE type_peripherique');
        $this->addSql('DROP TABLE utilisateur');
        $this->addSql('DROP TABLE version_office');
        $this->addSql('DROP TABLE vpn');
    }
}
