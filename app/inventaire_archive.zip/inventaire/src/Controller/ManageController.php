<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ManageController extends AbstractController
{
    /**
     * @Route("/manage", name="manage")
     */
    public function index(): Response
    {
        return $this->render('manage/index.html.twig', [
            'controller_name' => 'ManageController',
        ]);
    }
}
