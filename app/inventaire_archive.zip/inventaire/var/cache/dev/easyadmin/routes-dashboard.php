<?php return array (
  'admin' => 'App\\Controller\\Admin\\DashboardController::index',
);