<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/admin' => [[['_route' => 'admin', '_controller' => 'App\\Controller\\Admin\\DashboardController::index'], null, null, null, false, false, null]],
        '/base' => [[['_route' => 'base', '_controller' => 'App\\Controller\\BaseController::index'], null, null, null, false, false, null]],
        '/utilisateur' => [[['_route' => 'utilisateur', '_controller' => 'App\\Controller\\BaseController::utilisateur'], null, null, null, false, false, null]],
        '/manage' => [[['_route' => 'manage', '_controller' => 'App\\Controller\\ManageController::index'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/client/([^/]++)(*:58)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        58 => [
            [['_route' => 'client', '_controller' => 'App\\Controller\\BaseController::client'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
